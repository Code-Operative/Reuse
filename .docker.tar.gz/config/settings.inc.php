<?php
//@deprecated 1.7