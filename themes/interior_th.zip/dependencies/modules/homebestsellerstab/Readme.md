# Top-sellers block in tabs

## About

Adds a block displaying your store\'s top-selling products in tabs.
